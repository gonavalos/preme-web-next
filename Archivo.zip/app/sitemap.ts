// /app/sitemap.ts
import type { MetadataRoute } from "next";
export default function sitemap(): MetadataRoute.Sitemap {
  const base = "https://www.preme.com.ar";
  const now = new Date();
  return [
    { url: `${base}/`, lastModified: now },
    { url: `${base}/planes`, lastModified: now },
    { url: `${base}/prestadores`, lastModified: now },
    { url: `${base}/contacto`, lastModified: now },
    { url: `${base}/institucional`, lastModified: now },
    { url: `${base}/blog`, lastModified: now },
  ];
}